
<?php

require __DIR__ . '/config.php';

require_login();

$statuses = [
    'Aberta',
    'Em análise',
    'Aguardando peça',
    'Em reparo',
    'Concluída',
    'Cancelada'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();

    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'create') {
        $equip = (int) ($_POST['equipamento_id'] ?? 0);

        $st = $pdo->prepare('SELECT id FROM equipamentos WHERE id=?');
        $st->execute([$equip]);

        if ($st->fetch()) {
            $s = $pdo->prepare(
                'INSERT INTO ordens_servico(equipamento_id,status) VALUES(?,?)'
            );

            $s->execute([$equip, 'Aberta']);

            $_SESSION['flash'] = 'Ordem de serviço criada.';
        } else {
            $_SESSION['flash'] = 'Selecione um equipamento válido.';
        }
    } elseif ($action === 'update') {
        $id      = (int) ($_POST['id'] ?? 0);
        $status  = (string) ($_POST['status'] ?? 'Aberta');
        $diag    = trim((string) ($_POST['diagnostico'] ?? ''));
        $serv    = trim((string) ($_POST['servico_realizado'] ?? ''));
        $valor   = (float) ($_POST['valor'] ?? 0);

        if (in_array($status, $statuses, true) && $valor >= 0) {
            $s = $pdo->prepare(
                "UPDATE ordens_servico
                 SET status=?,
                     diagnostico=?,
                     servico_realizado=?,
                     valor=?,
                     data_conclusao=IF(?='Concluída',COALESCE(data_conclusao,NOW()),NULL)
                 WHERE id=?"
            );

            $s->execute([
                $status,
                $diag ?: null,
                $serv ?: null,
                $valor,
                $status,
                $id
            ]);

            $_SESSION['flash'] = 'Ordem atualizada.';
        }
    }

    header('Location: ordens.php');
    exit;
}

$equip = $pdo->query(
    'SELECT e.id,e.tipo,e.marca,e.modelo,c.nome AS cliente
     FROM equipamentos e
     JOIN clientes c ON c.id=e.cliente_id
     ORDER BY c.nome'
)->fetchAll();

$rows = $pdo->query(
    'SELECT os.*,e.tipo,e.marca,e.modelo,c.nome AS cliente
     FROM ordens_servico os
     JOIN equipamentos e ON e.id=os.equipamento_id
     JOIN clientes c ON c.id=e.cliente_id
     ORDER BY os.data_abertura DESC,os.id DESC'
)->fetchAll();

layout_start('Ordens de serviço');

echo '<section class="panel"><h2>Abrir ordem de serviço</h2>';

if (!$equip) {
    echo '<p>Cadastre um equipamento primeiro.</p>';
} else {
    echo '<form method="post">'
        . csrf_field()
        . '<input type="hidden" name="action" value="create">'
        . '<label>Equipamento *<select name="equipamento_id" required>';

    foreach ($equip as $e1) {
        echo '<option value="' . (int) $e1['id'] . '">'
            . e($e1['cliente'] . ' — ' . $e1['tipo'] . ' ' . $e1['marca'] . ' ' . $e1['modelo'])
            . '</option>';
    }

    echo '</select></label><button>Abrir OS</button></form>';
}

echo '</section>';

foreach ($rows as $r) {
    echo '<section class="panel">'
        . '<div class="oshead">'
        . '<h2>OS #' . (int) $r['id'] . ' — ' . e($r['cliente']) . '</h2>'
        . '<span class="status">' . e($r['status']) . '</span>'
        . '</div>'
        . '<p><strong>Abertura:</strong> ' . e($r['data_abertura'])
        . ' · <strong>Equipamento:</strong> '
        . e($r['tipo'] . ' ' . $r['marca'] . ' ' . $r['modelo'])
        . '</p>'
        . '<form method="post">'
        . csrf_field()
        . '<input type="hidden" name="action" value="update">'
        . '<input type="hidden" name="id" value="' . (int) $r['id'] . '">'
        . '<div class="grid">'
        . '<label>Status<select name="status">';

    foreach ($statuses as $s) {
        echo '<option'
            . ($s === $r['status'] ? ' selected' : '')
            . ' value="' . e($s) . '">'
            . e($s)
            . '</option>';
    }

    echo '</select></label>'
        . '<label>Valor (R$)<input type="number" min="0" step="0.01" name="valor" value="' . e((string) $r['valor']) . '"></label>'
        . '<label>Diagnóstico<textarea name="diagnostico">' . e($r['diagnostico']) . '</textarea></label>'
        . '<label>Serviço realizado<textarea name="servico_realizado">' . e($r['servico_realizado']) . '</textarea></label>'
        . '</div><button>Salvar atualização</button>'
        . '</form>'
        . '</section>';
}

layout_end();
