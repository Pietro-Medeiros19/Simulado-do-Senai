
<?php

require __DIR__ . '/config.php';

require_login();

$counts = [];

foreach (
    [
        'clientes' => 'Clientes',
        'equipamentos' => 'Equipamentos',
        'ordens_servico' => 'Ordens de serviço'
    ] as $t => $label
) {
    $counts[$label] = (int) $pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
}

layout_start('Painel principal');

echo '<p>Bem-vindo(a), <strong>' . e($_SESSION['user_name'] ?? 'Usuário') . '</strong>. Selecione um módulo para continuar.</p><div class="cards">';

foreach ($counts as $label => $n) {
    echo '<article class="panel"><h2>' . e($label) . '</h2><p class="number">' . $n . '</p></article>';
}

echo '</div><section class="panel"><h2>Acesso rápido</h2><p><a href="clientes.php">Gerenciar clientes</a> · <a href="equipamentos.php">Gerenciar equipamentos</a> · <a href="ordens.php">Acompanhar ordens</a></p></section>';

layout_end();