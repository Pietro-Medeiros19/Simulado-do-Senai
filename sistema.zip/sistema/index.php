
<?php

require __DIR__ . '/config.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();

    $email = trim((string) ($_POST['email'] ?? ''));
    $senha = (string) ($_POST['senha'] ?? '');

    $stmt = $pdo->prepare(
        'SELECT id,nome,email,senha_hash FROM usuarios WHERE email = ? LIMIT 1'
    );

    $stmt->execute([$email]);
    $u = $stmt->fetch();

    if ($u && password_verify($senha, $u['senha_hash'])) {
        session_regenerate_id(true);

        $_SESSION['user_id'] = (int) $u['id'];
        $_SESSION['user_name'] = $u['nome'];
        $_SESSION['last_activity'] = time();

        header('Location: dashboard.php');
        exit;
    }

    $error = 'E-mail ou senha inválidos.';
}

layout_start('Entrar no sistema');

if ($error) {
    echo '<p class="error">' . e($error) . '</p>';
}

echo '<section class="panel narrow">'
    . '<p>Acesse com suas credenciais cadastradas.</p>'
    . '<form method="post">'
    . csrf_field()
    . '<label>E-mail<input type="email" name="email" required autocomplete="username"></label>'
    . '<label>Senha<input type="password" name="senha" required autocomplete="current-password"></label>'
    . '<button>Entrar</button>'
    . '</form>'
    . '<p class="muted">Dados de demonstração constam no README.</p>'
    . '</section>';

layout_end();
