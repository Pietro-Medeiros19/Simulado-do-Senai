
<?php

require __DIR__ . '/config.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();

    $cliente = (int) ($_POST['cliente_id'] ?? 0);
    $tipo    = trim((string) ($_POST['tipo'] ?? ''));
    $marca   = trim((string) ($_POST['marca'] ?? ''));
    $modelo  = trim((string) ($_POST['modelo'] ?? ''));
    $serie   = trim((string) ($_POST['numero_serie'] ?? ''));
    $desc    = trim((string) ($_POST['descricao_problema'] ?? ''));

    $check = $pdo->prepare('SELECT id FROM clientes WHERE id=?');
    $check->execute([$cliente]);

    if ($check->fetch() && $tipo !== '' && $marca !== '' && $modelo !== '' && $desc !== '') {
        $stmt = $pdo->prepare(
            'INSERT INTO equipamentos(cliente_id,tipo,marca,modelo,numero_serie,descricao_problema) VALUES(?,?,?,?,?,?)'
        );

        $stmt->execute([
            $cliente,
            $tipo,
            $marca,
            $modelo,
            $serie ?: null,
            $desc
        ]);

        $_SESSION['flash'] = 'Equipamento cadastrado e associado ao cliente.';
        header('Location: equipamentos.php');
        exit;
    }

    $_SESSION['flash'] = 'Confira os campos obrigatórios e selecione um cliente válido.';
    header('Location: equipamentos.php');
    exit;
}

$clients = $pdo->query('SELECT id,nome FROM clientes ORDER BY nome')->fetchAll();

$rows = $pdo->query(
    'SELECT e.*,c.nome AS cliente_nome
     FROM equipamentos e
     JOIN clientes c ON c.id=e.cliente_id
     ORDER BY e.recebido_em DESC'
)->fetchAll();

layout_start('Gerenciamento de equipamentos');

echo '<section class="panel"><h2>Novo equipamento</h2>';

if (!$clients) {
    echo '<p>Cadastre um cliente antes de cadastrar equipamentos.</p>';
} else {
    echo '<form method="post">'
        . csrf_field()
        . '<div class="grid">'
        . '<label>Cliente *<select name="cliente_id" required>';

    foreach ($clients as $c) {
        echo '<option value="' . (int) $c['id'] . '">'
            . e($c['nome'])
            . '</option>';
    }

    echo '</select></label>'
        . '<label>Tipo *<input name="tipo" required placeholder="Notebook, desktop..."></label>'
        . '<label>Marca *<input name="marca" required></label>'
        . '<label>Modelo *<input name="modelo" required></label>'
        . '<label>Número de série<input name="numero_serie"></label>'
        . '<label class="full">Problema informado *<textarea name="descricao_problema" required></textarea></label>'
        . '</div><button>Cadastrar equipamento</button></form>';
}

echo '</section><section class="panel"><h2>Equipamentos cadastrados</h2><div class="tablewrap"><table><thead><tr><th>ID</th><th>Cliente</th><th>Tipo</th><th>Marca/modelo</th><th>Série</th><th>Problema</th></tr></thead><tbody>';

foreach ($rows as $r) {
    echo '<tr>'
        . '<td>' . (int) $r['id'] . '</td>'
        . '<td>' . e($r['cliente_nome']) . '</td>'
        . '<td>' . e($r['tipo']) . '</td>'
        . '<td>' . e($r['marca'] . ' ' . $r['modelo']) . '</td>'
        . '<td>' . e($r['numero_serie']) . '</td>'
        . '<td>' . e($r['descricao_problema']) . '</td>'
        . '</tr>';
}

if (!$rows) {
    echo '<tr><td colspan="6">Nenhum equipamento cadastrado.</td></tr>';
}

echo '</tbody></table></div></section>';

layout_end();
