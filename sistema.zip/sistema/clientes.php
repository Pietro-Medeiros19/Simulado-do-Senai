
<?php

require __DIR__ . '/config.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();

    $nome     = trim((string)($_POST['nome'] ?? ''));
    $telefone = trim((string)($_POST['telefone'] ?? ''));
    $email    = trim((string)($_POST['email'] ?? ''));
    $endereco = trim((string)($_POST['endereco'] ?? ''));

    if ($nome !== '' && $telefone !== '') {
        $stmt = $pdo->prepare(
            'INSERT INTO clientes(nome,telefone,email,endereco) VALUES(?,?,?,?)'
        );

        $stmt->execute([
            $nome,
            $telefone,
            $email ?: null,
            $endereco ?: null
        ]);

        $_SESSION['flash'] = 'Cliente cadastrado com sucesso.';
        header('Location: clientes.php');
        exit;
    }

    $_SESSION['flash'] = 'Preencha nome e telefone.';
    header('Location: clientes.php');
    exit;
}

$q = trim((string)($_GET['q'] ?? ''));

if ($q !== '') {
    $stmt = $pdo->prepare(
        'SELECT id,nome,telefone,email,endereco
         FROM clientes
         WHERE nome LIKE ? OR telefone LIKE ? OR email LIKE ?
         ORDER BY nome'
    );

    $like = '%' . $q . '%';
    $stmt->execute([$like, $like, $like]);
    $rows = $stmt->fetchAll();
} else {
    $rows = $pdo->query(
        'SELECT id,nome,telefone,email,endereco
         FROM clientes
         ORDER BY nome'
    )->fetchAll();
}

layout_start('Gerenciamento de clientes');

echo '<section class="panel">
    <h2>Novo cliente</h2>
    <form method="post">'
    . csrf_field() .
    '<div class="grid">
        <label>Nome *<input name="nome" required maxlength="120"></label>
        <label>Telefone *<input name="telefone" required maxlength="30"></label>
        <label>E-mail<input type="email" name="email" maxlength="150"></label>
        <label>Endereço<input name="endereco" maxlength="255"></label>
    </div>
    <button>Cadastrar cliente</button>
    </form>
</section>';

echo '<section class="panel">
    <h2>Pesquisar clientes</h2>
    <form method="get" class="search">
        <input name="q" value="' . e($q) . '" placeholder="Nome, telefone ou e-mail">
        <button>Buscar</button>
        <a class="button secondary" href="clientes.php">Limpar</a>
    </form>
    <div class="tablewrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>E-mail</th>
                    <th>Endereço</th>
                </tr>
            </thead>
            <tbody>';

foreach ($rows as $r) {
    echo '<tr>
        <td>' . (int)$r['id'] . '</td>
        <td>' . e($r['nome']) . '</td>
        <td>' . e($r['telefone']) . '</td>
        <td>' . e($r['email']) . '</td>
        <td>' . e($r['endereco']) . '</td>
    </tr>';
}

if (!$rows) {
    echo '<tr><td colspan="5">Nenhum registro encontrado.</td></tr>';
}

echo '</tbody>
        </table>
    </div>
</section>';

layout_end();
