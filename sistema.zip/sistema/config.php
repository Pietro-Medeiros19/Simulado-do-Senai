
<?php

declare(strict_types=1);

session_start();

const SESSION_TIMEOUT = 900; // 15 minutos de inatividade
const CPF_ENCRYPTION_KEY = 'TROQUE-ESTA-CHAVE-POR-32-BYTES-SEGURAS!!'; // configurar fora do código em produção

if (isset($_SESSION['last_activity']) && time() - (int)$_SESSION['last_activity'] > SESSION_TIMEOUT) {
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $p['path'],
            $p['domain'],
            $p['secure'],
            $p['httponly']
        );
    }

    session_destroy();
    session_start();

    $_SESSION['flash'] = 'Sua sessão expirou por inatividade. Entre novamente.';
}

$_SESSION['last_activity'] = time();

$host = getenv('DB_HOST') ?: '127.0.0.1';
$db   = getenv('DB_NAME') ?: 'saep_assistencia';
$user = getenv('DB_USER') ?: 'root';
$pass = getenv('DB_PASS') ?: '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    exit('Não foi possível conectar ao banco. Confira as configurações do ambiente.');
}

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function e(?string $v): string
{
    return htmlspecialchars($v ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf'] ?? '') . '">';
}

function check_csrf(): void
{
    if (
        $_SERVER['REQUEST_METHOD'] === 'POST' &&
        !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')
    ) {
        http_response_code(403);
        exit('Solicitação inválida. Atualize a página e tente novamente.');
    }
}

function require_login(): void
{
    if (empty($_SESSION['user_id'])) {
        header('Location: index.php');
        exit;
    }
}

function flash_message(): string
{
    if (empty($_SESSION['flash'])) {
        return '';
    }

    $m = e((string)$_SESSION['flash']);
    unset($_SESSION['flash']);

    return '<p class="notice">' . $m . '</p>';
}

function layout_start(string $title): void
{
    echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . e($title) . '</title><link rel="stylesheet" href="style.css"></head><body><header><strong>Assistência Técnica</strong>';

    if (!empty($_SESSION['user_id'])) {
        echo '<nav><a href="dashboard.php">Início</a><a href="clientes.php">Clientes</a><a href="equipamentos.php">Equipamentos</a><a href="ordens.php">Ordens de serviço</a><a href="logout.php">Sair</a></nav>';
    }

    echo '</header><main><h1>' . e($title) . '</h1>' . flash_message();
}

function layout_end(): void
{
    echo '</main><footer>Sistema demonstrativo • Desenvolvimento de Sistemas</footer></body></html>';
}
